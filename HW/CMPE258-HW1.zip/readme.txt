'''
Course: CMPE-258
Name: Chaoran Lei
SJSU ID: 015264119
'''

Note:
1. CMPE258-HW1.ipynb was coded and run on Jupyter Notebook.
2. Python version is 3.8.5
3. CMPE258-HW1.pdf is the screenshot of the code and result.
4. NN architecture block diagram.jpg is the image of the architecture.
5. Reference: https://victorzhou.com/blog/intro-to-neural-networks/